package com.jwtexample.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class SampleController {
	
	@GetMapping(value = "/api/getSampleData")
	public String getSampleData() {
		return "Sample Date Sent Successfully";
	}

}
