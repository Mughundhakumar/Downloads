import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { WorkProductComponent } from './work-product/work-product.component';

@Component({
  selector: 'app-timesheet-entry',
  templateUrl: './timesheet-entry.component.html',
  styleUrls: ['./timesheet-entry.component.scss']
})
export class TimesheetEntryComponent implements OnInit {

  columnDef = [
    {
      headerName: "First Name",
      field: "firstName"
    },
    {
      headerName: "Last Name",
      field: "lastName"
    },
    {
      headerName: "Age",
      field: "age"
    }
  ];

  rowData = [
    {
      firstName: 'John',
      lastName: 'John',
      age: 20
    },
    {
      firstName: 'ddfdf',
      lastName: 'sdfdsf',
      age: 20
    },
    {
      firstName: 'sdfdf',
      lastName: 'dfdsfsdf',
      age: 20
    }
  ];

  constructor(public dialog: MatDialog) { }

  ngOnInit(): void {
  }

  openDialog(): void {
    const dialogRef = this.dialog.open(WorkProductComponent, {
      width: '500px !important',
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed');
    });
  }

  onAddWorkProduct() {
    console.log('Function Called');
    const dialogRef = this.dialog.open(WorkProductComponent, {
      width: '250px',
      data: { name: 'this.name', animal: 'this.animal' }
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed');
    });

  }

}
