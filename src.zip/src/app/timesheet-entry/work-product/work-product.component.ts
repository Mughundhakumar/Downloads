import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { FormControl, FormGroup, FormBuilder, NgForm } from '@angular/forms';

@Component({
  selector: 'app-work-product',
  templateUrl: './work-product.component.html',
  styleUrls: ['./work-product.component.scss']
})
export class WorkProductComponent implements OnInit {


  constructor(
    public dialogRef: MatDialogRef<WorkProductComponent>,
  ) { }


  ngOnInit(): void {

  }

  onNoClick(): void {
    this.dialogRef.close();
  }

  onOkClick(formData: NgForm) {
    console.log('Sample Text');
    console.log(formData);
    this.dialogRef.close();
  }

}
